import java.util.Arrays;

public class BS {
	public class BubbleSortt {

		public static void main(String[] args) {
	int[]arr= {3,5,1,2,34,23,7,89,89,0,4};
	System.out.println("given arrays :");
	System.out.println(Arrays.toString(arr));
	BubbleSort(arr);
	System.out.println("sorted arrays :");
	System.out.println(Arrays.toString(arr));


		}

		private static void BubbleSort(int[] arr) {
			int n=arr.length;
			for(int i=0;i<n;i++) {
				for(int j=0;j<n-i-1;j++) {
					
					
					 if(arr[j] >arr[j+1]) {
						int temp=arr[j];
						arr[j]=arr[j+1];
						arr[j+1]=temp;
					 
				}
			}
			
		}

	 }
	}
}
