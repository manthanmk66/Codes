/**
 * 
 */
/**
 * @author IET
 *
 */
module Queue {
}