package com.demo.beans;

public class MyQueuee {
	private int[] queuearr;
	private int front;
	private int rear;
	private int size;
	public MyQueuee() {
		size=10;
		queuearr=new int[size];
		front=0;  
		rear=-1;  
}
	public MyQueuee(int s) {
		size=s;
		queuearr=new int[size];
		front=0;
		rear=-1;  
	
       }
	public boolean isFull() {
	
		return rear==size-1;
	
      }
}
