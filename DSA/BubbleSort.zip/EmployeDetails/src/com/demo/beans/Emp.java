package com.demo.beans;

public class Emp {
  public int empid;
  public String fullname;
  public String gender;
public Emp() {
	super();
}
public Emp(int empid, String fullname, String gender) {
	super();
	this.empid = empid;
	this.fullname = fullname;
	this.gender = gender;
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getFullname() {
	return fullname;
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
  
  
}

