
using System.ComponentModel.DataAnnotations;
namespace HRPortal.Models;

public class Company{
    public string companyname{get;set;}
    public string contactname{get;set;}
    public int EmployeeCount{get;set;}
}